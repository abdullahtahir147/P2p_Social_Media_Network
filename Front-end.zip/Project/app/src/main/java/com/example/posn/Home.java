package com.example.posn;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Home extends AppCompatActivity {
//private ImageView mImageView;
private Button LoginButton;
private Button SignUpButton;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        Log.v("new class", "home");
        //mImageView = (ImageView) findViewById(R.id.imageView) ;

        LoginButton = (Button) findViewById(R.id.LoginbtnHome);
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, LoginPage.class);
                startActivity(intent);
            }
        });

        SignUpButton = (Button) findViewById(R.id.SingUpbtnHome);
        SignUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, SignUpPage.class);
                startActivity(intent);
            }
        });
    }
}
